import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { BookingDetail } from 'src/models/booking-detail.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseUrl : any;

  constructor(private httpClient : HttpClient) { 
    this.baseUrl = 'http://localhost:9876/api/UserBookings/'
  }

  getUserSearchFlight(departurePlace : string, arrivalPlace : string) : Observable<any> {
    return this.httpClient.get(this.baseUrl + 'SearchFlightByUser/' + departurePlace + '/' + arrivalPlace)
    .pipe(map(res => res));
  }

  postUserBookingFlight(userBookingFlight : BookingDetail) : Observable<any> {
    return this.httpClient.post(this.baseUrl + 'BookFlightByUser', userBookingFlight);
  }

  getUserBookingDetails(pnrNumber : string) : Observable<any> {
    return this.httpClient.get(this.baseUrl + 'GetBookingDetailsOfUser/' + pnrNumber)
    .pipe(map(res=>res));
  }

  deleteUserBooking(email : string) : Observable<any> {
    return this.httpClient.delete(this.baseUrl + 'DeleteBookingByUser/' + email)
    .pipe(map(res=>res));
  }
}
