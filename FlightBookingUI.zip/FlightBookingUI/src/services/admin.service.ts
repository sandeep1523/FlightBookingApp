import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  baseUrl : any;
  loginUrl : any;

  constructor(private httpClient : HttpClient) { 
    this.baseUrl = 'http://localhost:9876/api/AdminControls/';
    this.loginUrl = 'http://localhost:9876/api/Login/'
  }

  loginUsingJwt(login : any) : Observable<any> {
    return this.httpClient.post(this.loginUrl + 'ValidateLoginUsingJwt', login)
    .pipe(map(res => res));
  }

  fetchAdminFlightInventory() : Observable<any> {
    const authToken = new HttpHeaders()
    .append("Authorization", "Bearer " + localStorage.getItem("token"));

    return this.httpClient.get(this.baseUrl + 'FetchAllInventoryByAdmin', {headers : authToken})
    .pipe(map(res => res));
  }

  postAdminAddFlight(adminAddFlight : any) : Observable<any> {
    const authToken = new HttpHeaders()
    .append("Authorization", "Bearer " + localStorage.getItem("token"));

    return this.httpClient.post(this.baseUrl + 'AddNewFlightByAdmin', adminAddFlight, {headers : authToken});
  }

  deleteAdminBlockFlight(id : string) : Observable<any> {
    const authToken = new HttpHeaders()
    .append("Authorization", "Bearer " + localStorage.getItem("token"));

    return this.httpClient.delete(this.baseUrl + 'RemoveFlightFromInventoryByAdmin/' + id, {headers : authToken})
    .pipe(map(res=>res));
  }
}
