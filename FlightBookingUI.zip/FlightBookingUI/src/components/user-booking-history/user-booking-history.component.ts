import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-user-booking-history',
  templateUrl: './user-booking-history.component.html',
  styleUrls: ['./user-booking-history.component.css']
})
export class UserBookingHistoryComponent implements OnInit {

  constructor(private userService : UserService) { }

  userBookingHistory : any;
  data : any;

  pnrNumber : any;
  
  fetchBookingHistory(userBookingHistory : NgForm){
    this.userService.getUserBookingDetails(userBookingHistory.value.pnrNumber)
      .subscribe(data => {
        this.data = data
        console.log(this.data);
      });
  }

  ngOnInit(): void {
  }

}
