import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCancelBookingComponent } from './user-cancel-booking.component';

describe('UserCancelBookingComponent', () => {
  let component: UserCancelBookingComponent;
  let fixture: ComponentFixture<UserCancelBookingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserCancelBookingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCancelBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
