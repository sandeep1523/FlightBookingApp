import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-user-cancel-booking',
  templateUrl: './user-cancel-booking.component.html',
  styleUrls: ['./user-cancel-booking.component.css']
})
export class UserCancelBookingComponent implements OnInit {

  constructor(private userService : UserService) { }

  userCancelBooking : any;
  data : any;

  email : any;

  cancelBooking(userCancelBooking : NgForm){
    this.userService.deleteUserBooking(userCancelBooking.value.email)
      .subscribe(data => {
        this.data = data
        console.log(this.data);
      });
  }
  cancelDisplayMsg : any;
  displayMsg(){
    this.cancelDisplayMsg='Booking is cancelled for user with Email Id';
    return this.cancelDisplayMsg;
  }

  ngOnInit(): void {
  }

}
