import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';

import { AdminService } from 'src/services/admin.service';

@Component({
  selector: 'app-admin-add-flight',
  templateUrl: './admin-add-flight.component.html',
  styleUrls: ['./admin-add-flight.component.css']
})
export class AdminAddFlightComponent implements OnInit {

  constructor(private adminService : AdminService) { }

  adminAddFlightForm : any;

  flightInventory : any = {
    flightDetail : {
      flightName : "",
      departurePlace : "",
      arrivalPlace : "",
      departureTime : new Date(),
      arrivalTime : new Date(),
      flightFare : 0
    },
    noOfBussinessClassSeats : 0,
    noOfEconomyClassSeats : 0,
    scheduledDays : "",
    instrumentUsed : ""
  };

  //flightInventoryId : any;
  flightName : any;
  departurePlace : any;
  arrivalPlace : any;
  departureTime : any;
  arrivalTime : any;
  flightFare : any;
  noOfBussinessClassSeats : any;
  noOfEconomyClassSeats : any;
  scheduledDays : any;
  instrumentUsed : any;

  addFlight(adminAddFlightForm : NgForm){
    this.flightInventory.flightDetail.flightName = adminAddFlightForm.value.flightName;
    this.flightInventory.flightDetail.departurePlace = adminAddFlightForm.value.departurePlace;
    this.flightInventory.flightDetail.arrivalPlace = adminAddFlightForm.value.arrivalPlace;
    this.flightInventory.flightDetail.departureTime = adminAddFlightForm.value.departureTime;
    this.flightInventory.flightDetail.arrivalTime = adminAddFlightForm.value.arrivalTime;
    this.flightInventory.flightDetail.flightFare = adminAddFlightForm.value.flightFare;
    this.flightInventory.noOfBussinessClassSeats = adminAddFlightForm.value.noOfBussinessClassSeats;
    this.flightInventory.noOfEconomyClassSeats = adminAddFlightForm.value.noOfEconomyClassSeats;
    this.flightInventory.scheduledDays = adminAddFlightForm.value.scheduledDays;
    this.flightInventory.instrumentUsed = adminAddFlightForm.value.instrumentUsed;

    this.adminService.postAdminAddFlight(this.flightInventory)
    .subscribe(data =>{
      data = this.flightInventory;
      console.log(data);
    })
  }

  addFlightDisplayMsg : any;
  displayMsg(){
    this.addFlightDisplayMsg='Flight is added to inventory!';
    return this.addFlightDisplayMsg;
  }

  ngOnInit(): void {
  }

}
