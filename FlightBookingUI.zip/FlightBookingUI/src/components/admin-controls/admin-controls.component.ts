import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-controls',
  templateUrl: './admin-controls.component.html',
  styleUrls: ['./admin-controls.component.css']
})
export class AdminControlsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
