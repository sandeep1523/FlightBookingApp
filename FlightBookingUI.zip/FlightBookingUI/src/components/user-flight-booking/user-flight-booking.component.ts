import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';

import { BookingDetail } from 'src/models/booking-detail.model';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-user-flight-booking',
  templateUrl: './user-flight-booking.component.html',
  styleUrls: ['./user-flight-booking.component.css']
})
export class UserFlightBookingComponent implements OnInit {

  constructor(private userService : UserService) { }

  userBookingForm : any;
  bookingDetail : any = {
    SeatNumber : "",
    userDetail : {
      userName : "",
      gender : "",
      email : ""
    },
    mealOpt : "",
    pnrNumber : "",
    flightDetail : {
      flightName : "",
      departurePlace : "",
      arrivalPlace : "",
      departureTime : new Date(),
      arrivalTime : new Date(),
      flightFare : 0
    }
  };

  userName : any;
  gender : any;
  email : any;
  flightName : any;
  departurePlace : any;
  arrivalPlace : any;
  departureTime : any;
  arrivalTime : any;
  flightFare : any;
  seatNumber : any;
  mealOpt : any;
  pnrNumber : any;

  gen : string[] =['Female', 'Male', 'Other'];
  meal : string[] =['Veg', 'Non-Veg'];

  // createFormControls(){
  //   this.userName = new FormControl('', Validators.required);
  //   this.gender = new FormControl('', Validators.required);
  //   this.email = new FormControl('', [Validators.required, Validators.pattern("[@]*[@]*")]);
  //   this.seatNumber = new FormControl('', Validators.required);
  //   this.mealOpt = new FormControl('', Validators.required);
  //   this.pnrNumber = new FormControl('', Validators.required);
  // }
  
  // createForms(){
  //   this.userBookingForm = new FormGroup({
  //     name : new FormGroup({
  //       userName : this.userName,
  //       gender : this.gender,
  //       email : this.email
  //     }),
  //     seatNumber : this.seatNumber,
  //     mealOpt : this.mealOpt,
  //     pnrNumber : this.pnrNumber
  //   });
  // }
  
  bookFlight(userBookingForm : NgForm){
    this.bookingDetail.userDetail.userName = userBookingForm.value.userName;
    this.bookingDetail.userDetail.email = userBookingForm.value.email;
    this.bookingDetail.userDetail.gender = userBookingForm.value.gender;
    this.bookingDetail.flightDetail.flightName = userBookingForm.value.flightName;
    this.bookingDetail.flightDetail.departurePlace = userBookingForm.value.departurePlace;
    this.bookingDetail.flightDetail.arrivalPlace = userBookingForm.value.arrivalPlace;
    this.bookingDetail.flightDetail.departureTime = userBookingForm.value.departureTime;
    this.bookingDetail.flightDetail.arrivalTime = userBookingForm.value.arrivalTime;
    this.bookingDetail.flightDetail.flightFare = userBookingForm.value.flightFare;
    this.bookingDetail.SeatNumber = userBookingForm.value.seatNumber;
    this.bookingDetail.mealOpt = userBookingForm.value.mealOpt;
    this.bookingDetail.pnrNumber = this.pnrNumber;

    this.userService.postUserBookingFlight(this.bookingDetail)
    .subscribe(data => {
      data = this.bookingDetail;
      console.log(data);
    });
  }

  bookingDisplayMsg : any;
  displayMsg(){
    this.bookingDisplayMsg='Booking is confirmed with PNR Number: ' + this.generatePnr();
    return this.bookingDisplayMsg;
  }

  generatePnr() : string {
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    this.pnrNumber = "PNR"
    for (var i = 5; i > 0; --i){
      this.pnrNumber += possible.charAt(Math.floor(Math.random() * possible.length));
    }   
    return this.pnrNumber;
  }


  ngOnInit(): void {
      // this.createFormControls();
      // this.createForms();
    }

}
