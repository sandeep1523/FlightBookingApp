import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminCancelFlightComponent } from './admin-cancel-flight.component';

describe('AdminCancelFlightComponent', () => {
  let component: AdminCancelFlightComponent;
  let fixture: ComponentFixture<AdminCancelFlightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminCancelFlightComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminCancelFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
