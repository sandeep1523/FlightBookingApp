import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { AdminService } from 'src/services/admin.service';

@Component({
  selector: 'app-admin-cancel-flight',
  templateUrl: './admin-cancel-flight.component.html',
  styleUrls: ['./admin-cancel-flight.component.css']
})
export class AdminCancelFlightComponent implements OnInit {

  constructor(private adminService : AdminService) { }

  adminCancelFlightForm : any;
  data: any;

  id : any;

  blockFlight(adminCancelFlightForm : NgForm){
    this.adminService.deleteAdminBlockFlight(adminCancelFlightForm.value.id)
      .subscribe(data => {
        this.data = data
        console.log(this.data);
      });
  }

  blockDisplayMsg : any;
  displayMsg(){
    this.blockDisplayMsg='Flight is blocked from inventory!';
    return this.blockDisplayMsg;
  }

  ngOnInit(): void {
  }

}
