import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from 'src/services/admin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private adminService : AdminService, private route : Router) { }

  loginForm : any;

  userName : any;
  password : any;

  loginObj : any = {
    userName : "",
    password : ""
  };
 

  login(loginForm : NgForm){
    this.loginObj.userName = loginForm.value.userName;
    this.loginObj.password = loginForm.value.password;

    this.adminService.loginUsingJwt(this.loginObj)
    .subscribe(data => {
      //data = this.loginObj;
      console.log(data);
      localStorage.setItem('token', data);

      this.route.navigate(['/admin-controls']);

    });
  }

  ngOnInit(): void {
  }

}
