import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminFetchInventoryComponent } from './admin-fetch-inventory.component';

describe('AdminFetchInventoryComponent', () => {
  let component: AdminFetchInventoryComponent;
  let fixture: ComponentFixture<AdminFetchInventoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminFetchInventoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminFetchInventoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
