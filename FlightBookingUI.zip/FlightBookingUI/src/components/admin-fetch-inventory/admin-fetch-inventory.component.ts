import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { AdminService } from 'src/services/admin.service';

@Component({
  selector: 'app-admin-fetch-inventory',
  templateUrl: './admin-fetch-inventory.component.html',
  styleUrls: ['./admin-fetch-inventory.component.css']
})
export class AdminFetchInventoryComponent implements OnInit {

  constructor(private adminService : AdminService) { }

  data : any;
  adminFetchInventoryForm : any;

  fetchInventory(adminFetchInventoryForm : NgForm){
    
    this.adminService.fetchAdminFlightInventory()
      .subscribe(data => {
        this.data = data
        console.log(this.data);
      });
  }

  ngOnInit(): void {
  }

}
