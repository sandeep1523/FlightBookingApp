import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-user-search-flight',
  templateUrl: './user-search-flight.component.html',
  styleUrls: ['./user-search-flight.component.css']
})
export class UserSearchFlightComponent implements OnInit {

  constructor(private userService : UserService) { }

  userSearchForm : any;
  data : any;

  departurePlace : any;
  arrivalPlace : any;

  searchFlight(userSearchForm : NgForm){
    
    this.userService.getUserSearchFlight(userSearchForm.value.departurePlace, userSearchForm.value.arrivalPlace)
      .subscribe(data => {
        this.data = data
        console.log(this.data);
      });
  }

  ngOnInit(): void {
    //this.searchFlight(this.userSearchForm);
  }

}
