import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { UserFlightBookingComponent } from '../components/user-flight-booking/user-flight-booking.component';
import { UserBookingHistoryComponent } from 'src/components/user-booking-history/user-booking-history.component';
import { UserSearchFlightComponent } from '../components/user-search-flight/user-search-flight.component';
import { UserCancelBookingComponent } from '../components/user-cancel-booking/user-cancel-booking.component';
import { AdminFetchInventoryComponent } from '../components/admin-fetch-inventory/admin-fetch-inventory.component';
import { AdminAddFlightComponent } from '../components/admin-add-flight/admin-add-flight.component';
import { AdminCancelFlightComponent } from '../components/admin-cancel-flight/admin-cancel-flight.component';
import { LoginComponent } from '../components/login/login.component';
import { AdminControlsComponent } from '../components/admin-controls/admin-controls.component';

import { UserService } from 'src/services/user.service';
import { AdminService } from 'src/services/admin.service';


@NgModule({
  declarations: [
    AppComponent,
    UserFlightBookingComponent,
    UserBookingHistoryComponent,
    UserSearchFlightComponent,
    UserCancelBookingComponent,
    AdminFetchInventoryComponent,
    AdminAddFlightComponent,
    AdminCancelFlightComponent,
    LoginComponent,
    AdminControlsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    UserService,
    AdminService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
