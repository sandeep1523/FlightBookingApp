import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UserBookingHistoryComponent } from 'src/components/user-booking-history/user-booking-history.component';
import { UserCancelBookingComponent } from 'src/components/user-cancel-booking/user-cancel-booking.component';
import { UserFlightBookingComponent } from 'src/components/user-flight-booking/user-flight-booking.component';
import { UserSearchFlightComponent } from 'src/components/user-search-flight/user-search-flight.component';
import { AdminFetchInventoryComponent } from 'src/components/admin-fetch-inventory/admin-fetch-inventory.component';
import { AdminAddFlightComponent } from 'src/components/admin-add-flight/admin-add-flight.component';
import { AdminCancelFlightComponent } from 'src/components/admin-cancel-flight/admin-cancel-flight.component';
import { LoginComponent } from 'src/components/login/login.component';
import { AdminControlsComponent } from 'src/components/admin-controls/admin-controls.component';

const routes: Routes = [
  {
    path : 'user-flight-booking', 
    component : UserFlightBookingComponent
  },
  {
    path : 'user-search-flight', 
    component : UserSearchFlightComponent
  },
  {
    path : 'user-booking-history', 
    component : UserBookingHistoryComponent
  },
  {
    path : 'user-cancel-booking', 
    component : UserCancelBookingComponent
  },
  {
    path : 'admin-fetch-inventory', 
    component : AdminFetchInventoryComponent
  },
  {
    path : 'admin-add-flight', 
    component : AdminAddFlightComponent
  },
  {
    path : 'admin-cancel-flight', 
    component : AdminCancelFlightComponent
  },
  {
    path : 'login', 
    component : LoginComponent
  },
  {
    path : 'admin-controls', 
    component : AdminControlsComponent
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
