import { FlightDetail } from "./flight-detail.model";
import { UserDetail } from "./user-detail.model"

export interface BookingDetail {
    
    id : number,
    SeatNumber : string,
    userDetail : UserDetail,
    mealOpt : string,
    pnrNumber : string,
    flightDetail : FlightDetail
}

