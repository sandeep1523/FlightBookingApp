export interface UserDetail {
    
    id : number;
    userName : string,
    gender : string,
    email : string
}
