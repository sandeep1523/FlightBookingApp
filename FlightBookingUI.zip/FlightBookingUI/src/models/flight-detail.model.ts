export interface FlightDetail {

    id : number,
    flightName : string,
    departurePlace : string,
    arrivalPlace : string,
    departureTime : Date,
    arrivalTime : Date,
    flightFare : number
}
