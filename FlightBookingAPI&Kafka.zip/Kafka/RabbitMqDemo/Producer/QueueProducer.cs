﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace Producer
{
    class QueueProducer
    {
        public static void Publish(IModel channel)
        {
            channel.QueueDeclare("demo",
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null
                );

            int count = 0;

            var message = new { Name = "Sandeep", Message = $"Team count:{count}" };
            var body = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(message));
            channel.BasicPublish("", "demo", null, body);
        }
    }
}
