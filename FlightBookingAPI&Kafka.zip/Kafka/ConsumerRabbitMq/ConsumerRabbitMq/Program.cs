﻿using RabbitMQ.Client;
using System;

namespace ConsumerRabbitMq
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var factory = new ConnectionFactory
            {
                Uri = new Uri("amqp://guest:guest@localhost:5672")
            };

            var connection = factory.CreateConnection();
            var channel = connection.CreateModel();

            Consumer.Consume(channel);
        }
    }
}
