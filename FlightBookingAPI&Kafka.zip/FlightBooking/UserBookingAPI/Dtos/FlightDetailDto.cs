﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Dtos
{
    public class FlightDetailDto
    {
        public int Id { get; set; }
        public string FlightName { get; set; }
        public string DeparturePlace { get; set; }
        public string ArrivalPlace { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public string FlightFare { get; set; }
    }
}
