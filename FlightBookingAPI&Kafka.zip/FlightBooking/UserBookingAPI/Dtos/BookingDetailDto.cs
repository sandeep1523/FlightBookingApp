﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Dtos
{
    public class BookingDetailDto
    {
        public int Id { get; set; }
        public string SeatNumber { get; set; }
        public UserDetailDto UserDetail { get; set; }
        public string MealOpt { get; set; }
        public string PnrNumber { get; set; }
        public FlightDetailDto FlightDetail { get; set; }
    }
}
