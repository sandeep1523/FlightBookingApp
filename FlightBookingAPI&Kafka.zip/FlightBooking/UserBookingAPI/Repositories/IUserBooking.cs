﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserBookingAPI.Models;

namespace UserBookingAPI.Repositories
{
    public interface IUserBooking
    {
        FlightDetail SearchFlight(string departurePlace, string arrivalPlace);
        BookingDetail GetBookingDetails(int userId);

        //BookingDetail BookFlight(BookingDetail bookingDetail);


    }
}
