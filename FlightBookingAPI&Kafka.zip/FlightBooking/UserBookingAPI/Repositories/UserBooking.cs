﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserBookingAPI.Models;

namespace UserBookingAPI.Repositories
{
    public class UserBooking : IUserBooking
    {
        private readonly UserBookingDbContext _context;

        public UserBooking(UserBookingDbContext _context)
        {
            this._context = _context;
        }

        public FlightDetail SearchFlight(string departurePlace, string arrivalPlace)
        {
            return (FlightDetail)_context.FlightDetail.Select(x => x.DeparturePlace == departurePlace && x.ArrivalPlace == arrivalPlace);
        }

        public BookingDetail GetBookingDetails(int userId)
        {
            return (BookingDetail)_context.BookingDetail.Include(x => x.UserDetail).Include(x => x.FlightDetail).Select(x => x.UserDetail.Id == userId);
        }

        //public BookingDetail BookFlight(BookingDetail bookingDetail)
        //{
        //    _context.Add(bookingDetail);
        //    _context.SaveChanges();
        //}
    }
}
