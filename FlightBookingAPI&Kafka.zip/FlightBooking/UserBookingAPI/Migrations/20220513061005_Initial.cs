﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace UserBookingAPI.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FlightDetail",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FlightName = table.Column<string>(nullable: false),
                    DeparturePlace = table.Column<string>(nullable: false),
                    ArrivalPlace = table.Column<string>(nullable: false),
                    DepartureTime = table.Column<DateTime>(nullable: false),
                    ArrivalTime = table.Column<DateTime>(nullable: false),
                    FlightFare = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlightDetail", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserDetail",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    UserName = table.Column<string>(nullable: false),
                    Gender = table.Column<string>(nullable: true),
                    Email = table.Column<string>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserDetail", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BookingDetail",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SeatNumber = table.Column<string>(nullable: false),
                    UserDetailId = table.Column<int>(nullable: true),
                    MealOpt = table.Column<string>(nullable: true),
                    PnrNumber = table.Column<string>(nullable: false),
                    FlightDetailId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookingDetail", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BookingDetail_FlightDetail_FlightDetailId",
                        column: x => x.FlightDetailId,
                        principalTable: "FlightDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BookingDetail_UserDetail_UserDetailId",
                        column: x => x.UserDetailId,
                        principalTable: "UserDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "FlightDetail",
                columns: new[] { "Id", "ArrivalPlace", "ArrivalTime", "DeparturePlace", "DepartureTime", "FlightFare", "FlightName" },
                values: new object[,]
                {
                    { 1001, "Mumbai", new DateTime(2022, 6, 1, 10, 15, 0, 0, DateTimeKind.Unspecified), "Delhi", new DateTime(2022, 6, 1, 8, 0, 0, 0, DateTimeKind.Unspecified), "7000", "Air India" },
                    { 1002, "Chennai", new DateTime(2022, 6, 1, 11, 15, 0, 0, DateTimeKind.Unspecified), "Delhi", new DateTime(2022, 6, 1, 9, 0, 0, 0, DateTimeKind.Unspecified), "6500", "Air India" },
                    { 1003, "Kolkata", new DateTime(2022, 6, 1, 16, 15, 0, 0, DateTimeKind.Unspecified), "Delhi", new DateTime(2022, 6, 1, 14, 0, 0, 0, DateTimeKind.Unspecified), "6000", "Air India" },
                    { 1004, "Jaipur", new DateTime(2022, 6, 2, 10, 15, 0, 0, DateTimeKind.Unspecified), "Delhi", new DateTime(2022, 6, 2, 8, 0, 0, 0, DateTimeKind.Unspecified), "4500", "Indigo Airline" },
                    { 1005, "Bangalore", new DateTime(2022, 6, 1, 9, 0, 0, 0, DateTimeKind.Unspecified), "Delhi", new DateTime(2022, 6, 1, 7, 0, 0, 0, DateTimeKind.Unspecified), "6500", "Indigo Airline" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_BookingDetail_FlightDetailId",
                table: "BookingDetail",
                column: "FlightDetailId");

            migrationBuilder.CreateIndex(
                name: "IX_BookingDetail_UserDetailId",
                table: "BookingDetail",
                column: "UserDetailId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BookingDetail");

            migrationBuilder.DropTable(
                name: "FlightDetail");

            migrationBuilder.DropTable(
                name: "UserDetail");
        }
    }
}
