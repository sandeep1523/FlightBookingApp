﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace UserBookingAPI.Migrations
{
    public partial class InsertValues : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "BookingDetail",
                columns: new[] { "Id", "FlightDetailId", "MealOpt", "PnrNumber", "SeatNumber", "UserDetailId" },
                values: new object[,]
                {
                    { 3111, null, "Veg", "AIRIND564321", "1A-23", null },
                    { 3112, null, "Veg", "AIRIND564321", "1A-15", null }
                });

            migrationBuilder.InsertData(
                table: "UserDetail",
                columns: new[] { "Id", "Email", "Gender", "UserName" },
                values: new object[,]
                {
                    { 1, "batm@dc.com", "Male", "Batman" },
                    { 2, "capam@marvel.com", "Male", "CaptainAmerica" },
                    { 3, "wonderw@dc.com", "Female", "WonderWoman" },
                    { 4, "cmarvel@marvel.com", "Female", "CaptainMarvel" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "BookingDetail",
                keyColumn: "Id",
                keyValue: 3111);

            migrationBuilder.DeleteData(
                table: "BookingDetail",
                keyColumn: "Id",
                keyValue: 3112);

            migrationBuilder.DeleteData(
                table: "UserDetail",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "UserDetail",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "UserDetail",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "UserDetail",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
