﻿using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserBookingAPI.Dtos;
using UserBookingAPI.Models;
using UserBookingAPI.Repositories;

namespace UserBookingAPI.Controllers
{
    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserBookingsController : Controller
    {
        private readonly IUserBooking _userBooking;
        private readonly UserBookingDbContext _context;
        private readonly IMapper _mapper;
        //private readonly AdminControlDbContext _adminDbContext;

        DateTime now = DateTime.Now;
        public UserBookingsController(IUserBooking userBooking, UserBookingDbContext context, IMapper mapper)
        {
            this._userBooking = userBooking;
            this._context = context;
            this._mapper = mapper;
        }

        [HttpGet]
        [Route("SearchFlightByUser/{departurePlace}/{arrivalPlace}")]
        public IActionResult SearchFlightByUser([FromRoute] string departurePlace, [FromRoute] string arrivalPlace)
        {           
            if(departurePlace == null || arrivalPlace == null)
            {
                return NotFound();
            }
            if(departurePlace == arrivalPlace)
            {
                return BadRequest();
            }
            var searchFlight = _context.FlightDetail.
                SingleOrDefault(x => x.DeparturePlace == departurePlace && x.ArrivalPlace == arrivalPlace);

            return Ok(Mapper.Map<FlightDetail, FlightDetailDto>(searchFlight));
        }

        [HttpPost]
        [Route("BookFlightByUser")]
        public IActionResult BookFlightByUser([Bind("Id,SeatNumber,MealOpt,PnrNumber")] BookingDetailDto bookingDetailDto)
        {
            ////fetching the actual flightId from flightDetails table to be mapped to bookingDetails table as foreign key
            //var flightDetailId = _context.FlightDetail.Where(c => c.DeparturePlace == bookingDetailDto.FlightDetail.DeparturePlace
            //                                                    && c.ArrivalPlace == bookingDetailDto.FlightDetail.ArrivalPlace
            //                                                    && c.DepartureTime == bookingDetailDto.FlightDetail.DepartureTime
            //                                                    && c.ArrivalTime == bookingDetailDto.FlightDetail.ArrivalTime)
            //                                          .Select(c => c.Id).Single();
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            //adding new booking details from UI
            var bookingDetail = Mapper.Map<BookingDetailDto, BookingDetail>(bookingDetailDto);
            _context.Add(bookingDetail);
            _context.SaveChanges();

            #region manipulating foreign key
            ////removing newly created duplicate flightId
            //var flightId = _context.BookingDetail.Where(c => c.Id == bookingDetail.Id).Select(c => c.FlightDetail.Id).Single();
            //var flightIdInDb = _context.FlightDetail.Single(c => c.Id == flightId);
            //_context.FlightDetail.Remove(flightIdInDb);

            ////setting actual flightId in booking details table as foreign key
            //bookingDetail.FlightDetail.Id = flightDetailId;
            //_context.SaveChanges(); 
            #endregion

            bookingDetailDto.Id = bookingDetail.Id;
            return Ok(bookingDetail);
        }

        [HttpGet]
        [Route("GetBookingDetailsOfUser/{pnrNumber}")]
        public IActionResult GetBookingDetailsOfUser([FromRoute] string pnrNumber)
        {
            var userInDb = _context.BookingDetail.Include(x => x.UserDetail)
                .Include(x => x.FlightDetail).SingleOrDefault(x => x.PnrNumber == pnrNumber);
            if (userInDb == null)
            {
                return NotFound();
            }
            return Ok(Mapper.Map<BookingDetail, BookingDetailDto>(userInDb));
        }

        [HttpDelete]
        [Route("DeleteBookingByUser/{email}")]
        public IActionResult DeleteBookingByUser([FromRoute] string email)
        {
            var userId = _context.BookingDetail.Where(c => c.UserDetail.Email == email).Select(c => c.UserDetail.Id).Single();
            var userIdInDb = _context.UserDetail.Single(c => c.Id == userId);

            var bookingDetailInDb = _context.BookingDetail.Include(x => x.UserDetail)
                .Include(x => x.FlightDetail).SingleOrDefault(c => c.UserDetail.Email == email);
            if(bookingDetailInDb == null)
            {
                return NotFound();
            }

            //var deleteBookingDto = Mapper.Map<BookingDetail, BookingDetailDto>(bookingDetailInDb);
            _context.BookingDetail.Remove(bookingDetailInDb);
            _context.UserDetail.Remove(userIdInDb);
            _context.SaveChanges();
            return Ok();
        }
    }
}
