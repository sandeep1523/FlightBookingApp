﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Models
{
    public class BookingDetail
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string SeatNumber { get; set; }

        public UserDetail UserDetail { get; set; }

        public string MealOpt { get; set; }

        [Required]
        public string PnrNumber { get; set; }

        public FlightDetail FlightDetail { get; set; }
    }
}
