﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Models
{
    public class FlightDetail
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string FlightName { get; set; }

        [Required]
        public string DeparturePlace { get; set; }

        [Required]
        public string ArrivalPlace { get; set; }

        [Required]
        public DateTime DepartureTime { get; set; }

        [Required]
        public DateTime ArrivalTime { get; set; }

        [Required]
        public string FlightFare { get; set; }
    }
}
