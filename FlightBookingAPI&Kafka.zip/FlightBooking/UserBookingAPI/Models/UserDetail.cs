﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Models
{
    public class UserDetail
    {
        [Required]
        [Display(Name ="User Id")]
        public int Id { get; set; }

        [Required]
        public string UserName { get; set; }

        public string Gender { get; set; }

        [Required]
        [EmailAddress]
        public string Email  { get; set; }
    }
}
