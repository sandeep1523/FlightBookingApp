﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UserBookingAPI.Models
{
    public class UserBookingDbContext : DbContext
    {
        public UserBookingDbContext(DbContextOptions<UserBookingDbContext> options) : base(options)
        {

        }

        public DbSet<UserDetail> UserDetail { get; set; }
        public DbSet<BookingDetail> BookingDetail { get; set; }
        public DbSet<FlightDetail> FlightDetail { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FlightDetail>().HasData(
                new FlightDetail
                {
                    Id = 1001,
                    FlightName = "Air India",
                    DeparturePlace = "Delhi",
                    ArrivalPlace = "Mumbai",
                    DepartureTime = new DateTime(2022, 06, 01, 08, 00, 00),
                    ArrivalTime = new DateTime(2022, 06, 01, 10, 15, 00),
                    FlightFare = "7000"
                },
                new FlightDetail
                {
                    Id = 1002,
                    FlightName = "Air India",
                    DeparturePlace = "Delhi",
                    ArrivalPlace = "Chennai",
                    DepartureTime = new DateTime(2022, 06, 01, 09, 00, 00),
                    ArrivalTime = new DateTime(2022, 06, 01, 11, 15, 00),
                    FlightFare = "6500"
                },
                new FlightDetail
                {
                    Id = 1003,
                    FlightName = "Air India",
                    DeparturePlace = "Delhi",
                    ArrivalPlace = "Kolkata",
                    DepartureTime = new DateTime(2022, 06, 01, 14, 00, 00),
                    ArrivalTime = new DateTime(2022, 06, 01, 16, 15, 00),
                    FlightFare = "6000"
                },
                new FlightDetail
                {
                    Id = 1004,
                    FlightName = "Indigo Airline",
                    DeparturePlace = "Delhi",
                    ArrivalPlace = "Jaipur",
                    DepartureTime = new DateTime(2022, 06, 02, 08, 00, 00),
                    ArrivalTime = new DateTime(2022, 06, 02, 10, 15, 00),
                    FlightFare = "4500"
                },
                new FlightDetail
                {
                    Id = 1005,
                    FlightName = "Indigo Airline",
                    DeparturePlace = "Delhi",
                    ArrivalPlace = "Bangalore",
                    DepartureTime = new DateTime(2022, 06, 01, 07, 00, 00),
                    ArrivalTime = new DateTime(2022, 06, 01, 09, 00, 00),
                    FlightFare = "6500"
                }
            );

            modelBuilder.Entity<UserDetail>().HasData(
                new UserDetail
                {
                    Id = 1,
                    UserName = "Batman",
                    Gender = "Male",
                    Email = "batm@dc.com",
                },
                new UserDetail
                {
                    Id = 2,
                    UserName = "CaptainAmerica",
                    Gender = "Male",
                    Email = "capam@marvel.com",
                },
                new UserDetail
                {
                    Id = 3,
                    UserName = "WonderWoman",
                    Gender = "Female",
                    Email = "wonderw@dc.com",
                },
                new UserDetail
                {
                    Id = 4,
                    UserName = "CaptainMarvel",
                    Gender = "Female",
                    Email = "cmarvel@marvel.com",
                }
             );

            modelBuilder.Entity<BookingDetail>().HasData(
                new BookingDetail
                {
                    Id = 3111,
                    SeatNumber = "1A-23",
                    //UserDetail = new UserDetail { Id = 1},
                    MealOpt = "Veg",
                    PnrNumber = "AIRIND564321"
                }
                ,
                new BookingDetail
                {
                    Id = 3112,
                    SeatNumber = "1A-15",
                    //UserDetail = new UserDetail { Id = 4 },
                    MealOpt = "Veg",
                    PnrNumber = "AIRIND564321"
                }
             );
        }

    }
}
