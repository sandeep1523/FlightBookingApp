﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AdminControlAPI.Migrations
{
    public partial class AddFlightInventory : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.CreateTable(
            //    name: "FlightDetail",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(nullable: false)
            //            .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
            //        FlightName = table.Column<string>(nullable: false),
            //        DeparturePlace = table.Column<string>(nullable: false),
            //        ArrivalPlace = table.Column<string>(nullable: false),
            //        DepartureTime = table.Column<DateTime>(nullable: false),
            //        ArrivalTime = table.Column<DateTime>(nullable: false),
            //        FlightFare = table.Column<string>(nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_FlightDetail", x => x.Id);
            //    });

            migrationBuilder.CreateTable(
                name: "FlightInventory",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    FlightDetailId = table.Column<int>(nullable: false),
                    NoOfBussinessClassSeats = table.Column<int>(nullable: false),
                    NoOfEconomyClassSeats = table.Column<int>(nullable: false),
                    ScheduledDays = table.Column<string>(nullable: false),
                    InstrumentUsed = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FlightInventory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FlightInventory_FlightDetail_FlightDetailId",
                        column: x => x.FlightDetailId,
                        principalTable: "FlightDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FlightInventory_FlightDetailId",
                table: "FlightInventory",
                column: "FlightDetailId");

            migrationBuilder.Sql("INSERT INTO FlightInventory VALUES(1001, 30, 60, 'SUN,MON,WED', NULL)");
            migrationBuilder.Sql("INSERT INTO FlightInventory VALUES(1002, 24, 72, 'SUN,MON,FRI,SAT', NULL)");
            migrationBuilder.Sql("INSERT INTO FlightInventory VALUES(1003, 30, 60, 'SUN,MON,WED,THUR', NULL)");
            migrationBuilder.Sql("INSERT INTO FlightInventory VALUES(1004, 36, 60, 'SUN,TUE,SAT', NULL)");
            migrationBuilder.Sql("INSERT INTO FlightInventory VALUES(1005, 18, 42, 'SUN,FRI,SAT', NULL)");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FlightInventory");

            migrationBuilder.DropTable(
                name: "FlightDetail");
        }
    }
}
