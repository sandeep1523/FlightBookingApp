﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminControlAPI.Repositories
{
    public interface IAdminControl
    {
        string LoginUsingJwt(string userName);
    }
}
