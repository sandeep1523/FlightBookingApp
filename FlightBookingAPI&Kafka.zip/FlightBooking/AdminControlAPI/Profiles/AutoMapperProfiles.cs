﻿using AdminControlAPI.Dtos;
using AdminControlAPI.Models;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminControlAPI.Profiles
{
    public class AutoMapperProfiles : Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<FlightInventory, FlightInventoryDto>().ReverseMap();
        }
    }
}
