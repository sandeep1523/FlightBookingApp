﻿using AdminControlAPI.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserBookingAPI.Models;

namespace AdminControlAPI.Controllers
{   
    [Authorize]
    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class AdminControlsController : Controller
    {
        private readonly AdminControlDbContext _context;
        private readonly UserBookingDbContext _userDbcontext;

        public AdminControlsController(AdminControlDbContext context, UserBookingDbContext userDbContext)
        {
            this._context = context;
            this._userDbcontext = userDbContext;
        }

        [HttpGet]
        [Route("FetchInventoryByAdmin/{flightId}")]
        public IActionResult FetchInventoryByAdmin([FromRoute] int? flightId)
        {
            var flightIdInDb = _context.FlightInventory.Include(x => x.FlightDetail).Where(x => x.FlightDetail.Id == flightId);
            if (flightId == null)
            {
                return NotFound();
            }
            return Ok(flightIdInDb);
        }

        [HttpGet]
        [Route("FetchAllInventoryByAdmin")]
        public IActionResult FetchAllInventoryByAdmin()
        {
            return Ok(_context.FlightInventory.Include(x => x.FlightDetail));
        }

        [HttpPost]
        [Route("AddNewFlightByAdmin")]
        public IActionResult AddNewFlightByAdmin([Bind("Id,NoOfBussinessClassSeats,NoOfEconomyClassSeats,ScheduledDays,InstrumentUsed")] FlightInventory flightInventory)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            _context.Add(flightInventory);
            _context.SaveChanges();
            return Ok();
        }

        [HttpPut]
        [Route("ManageInventoryByAdmin/{flightInventoryId}")]
        public IActionResult ManageInventoryByAdmin([Bind("Id,NoOfBussinessClassSeats,NoOfEconomyClassSeats,ScheduledDays,InstrumentUsed")] FlightInventory flightInventory, [FromRoute] int flightInventoryId)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var flightInventoryInDb = _context.FlightInventory.SingleOrDefault(c => c.Id == flightInventoryId);
            if (flightInventoryInDb == null)
            {
                return NotFound();
            }

            flightInventoryInDb.FlightDetail = flightInventory.FlightDetail;
            flightInventoryInDb.NoOfBussinessClassSeats = flightInventory.NoOfBussinessClassSeats;
            flightInventoryInDb.NoOfEconomyClassSeats = flightInventory.NoOfEconomyClassSeats;
            flightInventoryInDb.ScheduledDays = flightInventory.ScheduledDays;
            flightInventoryInDb.InstrumentUsed = flightInventory.InstrumentUsed;

            // _context.FlightInventory.Update(flightInventoryInDb);
            

            //_context.FlightInventory.Attach(flightInventoryInDb);
            _context.Entry(flightInventoryInDb).State = EntityState.Modified;
            //_context.Entry(flightInventoryInDb).Reference().IsModified = false;

            //bool val = await TryUpdateModelAsync<FlightInventory>(flightInventoryInDb);
            //_context.Update(flightInventoryInDb);
            _context.SaveChanges();
            return Ok();
        }

        [HttpDelete]
        [Route("RemoveFlightFromInventoryByAdmin/{flightInventoryId}")]
        public IActionResult RemoveFlightFromInventoryByAdmin([FromRoute] int flightInventoryId)
        {
            var flightInventoryInDb = _context.FlightInventory.SingleOrDefault(c => c.Id == flightInventoryId);

            var flightDetailId = _context.FlightInventory.Where(c => c.Id == flightInventoryId).Select(c => c.FlightDetail.Id).Single();
            var flightDetailsInDb = _userDbcontext.FlightDetail.Single(x => x.Id == flightDetailId);


            if (flightInventoryInDb == null || flightDetailsInDb == null)
            {
                return NotFound();
            }

            _userDbcontext.FlightDetail.Remove(flightDetailsInDb);
            _context.FlightInventory.Remove(flightInventoryInDb);

            _context.SaveChanges();
            _userDbcontext.SaveChanges();
            return Ok();
        }
    }
}
