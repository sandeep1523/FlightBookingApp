﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AdminControlAPI.Models;

namespace AdminControlAPI.Controllers
{
    public class TestController : Controller
    {
        private readonly AdminControlDbContext _context;

        public TestController(AdminControlDbContext context)
        {
            _context = context;
        }

        // GET: FlightInventories
        public async Task<IActionResult> Index()
        {
            return View(await _context.FlightInventory.ToListAsync());
        }

        // GET: FlightInventories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var flightInventory = await _context.FlightInventory
                .FirstOrDefaultAsync(m => m.Id == id);
            if (flightInventory == null)
            {
                return NotFound();
            }

            return View(flightInventory);
        }

        // GET: FlightInventories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: FlightInventories/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,NoOfBussinessClassSeats,NoOfEconomyClassSeats,ScheduledDays,InstrumentUsed")] FlightInventory flightInventory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(flightInventory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(flightInventory);
        }

        // GET: FlightInventories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var flightInventory = await _context.FlightInventory.FindAsync(id);
            if (flightInventory == null)
            {
                return NotFound();
            }
            return View(flightInventory);
        }

        // POST: FlightInventories/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,NoOfBussinessClassSeats,NoOfEconomyClassSeats,ScheduledDays,InstrumentUsed")] FlightInventory flightInventory)
        {
            if (id != flightInventory.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(flightInventory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FlightInventoryExists(flightInventory.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(flightInventory);
        }

        // GET: FlightInventories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var flightInventory = await _context.FlightInventory
                .FirstOrDefaultAsync(m => m.Id == id);
            if (flightInventory == null)
            {
                return NotFound();
            }

            return View(flightInventory);
        }

        // POST: FlightInventories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var flightInventory = await _context.FlightInventory.FindAsync(id);
            _context.FlightInventory.Remove(flightInventory);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FlightInventoryExists(int id)
        {
            return _context.FlightInventory.Any(e => e.Id == id);
        }
    }
}
