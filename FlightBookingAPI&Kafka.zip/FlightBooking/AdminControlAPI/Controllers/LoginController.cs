﻿using AdminControlAPI.Models;
using AdminControlAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminControlAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : Controller
    {
        private readonly IAdminControl _adminControl;
        private readonly AdminControlDbContext _context;

        public LoginController(IAdminControl adminControl, AdminControlDbContext context)
        {
            this._adminControl = adminControl;
            this._context = context;
        }

        [HttpPost]
        [Route("ValidateLoginUsingJwt")]
        public IActionResult ValidateLoginUsingJwt([FromBody] Login login)
        {
            var user = _context.Login.Where(x => x.UserName == login.UserName && x.Password == login.Password)
                .Select(l => l.UserName);
            if(user == null)
            {
                return BadRequest();
            }
            var token = _adminControl.LoginUsingJwt(user.ToString());
            var tokenToJson = JsonConvert.SerializeObject(token);
            return Ok(tokenToJson);
        }
    }
}
