﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using UserBookingAPI.Models;

namespace AdminControlAPI.Models
{
    public class FlightInventory
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public FlightDetail FlightDetail { get; set; }
        [Required]
        public int NoOfBussinessClassSeats { get; set; }
        [Required]
        public int NoOfEconomyClassSeats { get; set; }
        [Required]
        public string ScheduledDays { get; set; }
        public string InstrumentUsed { get; set; }
    }
}
