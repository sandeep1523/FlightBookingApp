﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminControlAPI.Models
{
    public class AdminControlDbContext : DbContext
    {
        public AdminControlDbContext(DbContextOptions<AdminControlDbContext> options) : base(options)
        {

        }

        public DbSet<FlightInventory> FlightInventory { get; set; }
        public DbSet<Login> Login { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
        }



    }
}
